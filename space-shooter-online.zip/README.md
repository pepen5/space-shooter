# 🚀 Space Shooter

Game tembak-tembakan luar angkasa dengan suara modern dan kapal berwarna cream muda.

## 🎮 Cara Main
- Gunakan tombol **←** dan **→** untuk bergerak.
- Tekan **Spasi** untuk menembak.
- Klik tombol **Mute/Unmute** di pojok untuk mengatur suara.

## 🌐 Cara Upload ke GitHub Pages

1. Masuk ke akun [GitHub](https://github.com).
2. Buat repository baru bernama **space-shooter** (public).
3. Upload file `index.html` ke repository tersebut.
4. Pergi ke **Settings → Pages**.
5. Di bagian "Build and deployment", pilih:  
   - **Source:** `Deploy from a branch`  
   - **Branch:** `main` → `/ (root)`
6. Klik **Save**.
7. Setelah beberapa detik, game kamu bisa diakses di:  
   👉 `https://username.github.io/space-shooter/`

Selamat bermain dan berbagi! 🚀
